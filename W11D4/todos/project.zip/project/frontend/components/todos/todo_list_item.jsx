import React from 'react';

const TodoListItem = ({ todo }) => {
  // debugger
  return (
    <li> {todo.title} </li>
  )
}

export default TodoListItem;